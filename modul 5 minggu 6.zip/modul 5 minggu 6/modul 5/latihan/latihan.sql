create database Data_kendaraan;

create table kendaraan(
no_plat varchar(20) primary key,
tahun char(10),
tarif varchar(10),
status varchar(20)
);

create table transaksi(
no_transaksi int(10) primary key,
tanggal_pesan date,
tanggal_pinjam date,
tanggal_kembali_rencana date,
jam_kembali date,
tanggal_kembali_realisasi date,
denda char(20),
kilometer_pinjam char(20),
kilometer_kembali char(20),
bbm_pinjam char(20),
bbm_kembali char(20) ,
kondisi_mobil_pinjam varchar(20) ,
kondisi_mobil_kembali varchar(20) ,
kerusakan varchar(20),
biaya_kerusakan char(20),
biaya_bbm char(20)
);

create table supir(
nama varchar(24),
alamat varchar(25),
telepon char(38),
sim varchar(30),
tarif char(37)
);

create table pelanggan (
no_ktp int(79)primary key,
nama varchar(34),
alamat varchar(35),
telepon char(45)
);
