<h1> welcome to PDO CRUD</h1>
<h2> tambah data sekolah</h2>
<form method="POST" action="proses/sekolah/save.php"
enctype="multipart/form-data">
<table>
<tr>
	<td> nama</td>
	<td> <input type="text" name="nama"></td>
</tr>
<tr>
	<td> alamat</td>
	<td> <input type="text" name="alamat"></td>
</tr>
<tr>
	<td> logo</td>
	<td> <input type="file" name="logo"></td>
</tr>
<tr>
	<td></td>
	<td> <button type="submit">simpan</button></td>
</tr>
</table>
</form>