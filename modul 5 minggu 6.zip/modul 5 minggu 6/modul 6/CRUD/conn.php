<?php
$engi = "mysql";
$host = "localhost";
$dbse = "CRUD_PDO";
$user = "root";
$pass = "";
$koneksi = new PDO($engi.':dbname='.$dbse.";host=".$host,
$user,$pass);
?>